package org.beiming;

public abstract class CashSuper {
    abstract double acceptCash(double money);
}
